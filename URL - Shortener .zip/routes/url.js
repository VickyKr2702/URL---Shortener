import express from 'express';
import Url from '../models/Url.js';
import { nanoid } from 'nanoid';
import validUrl from 'valid-url';

const router = express.Router();
const BASE_URL = 'https://short.ly';

// POST /shorten
router.post('/shorten', async (req, res) => {
  const { url } = req.body;

  if (!validUrl.isWebUri(url)) {
    return res.status(400).json({ error: 'Invalid URL format' });
  }

  const shortCode = nanoid(6);
  const shortUrl = `${BASE_URL}/${shortCode}`;

  try {
    const newUrl = new Url({
      originalUrl: url,
      shortCode,
    });

    await newUrl.save();
    res.json({ shortUrl });
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

// GET /:code
router.get('/:code', async (req, res) => {
  const { code } = req.params;

  try {
    const urlEntry = await Url.findOne({ shortCode: code });

    if (!urlEntry) {
      return res.status(404).json({ error: 'Short URL not found' });
    }

    // Optional Expiry Check
    if (urlEntry.expiryDate && new Date() > urlEntry.expiryDate) {
      return res.status(410).json({ error: 'URL has expired' });
    }

    urlEntry.clickCount += 1;
    await urlEntry.save();

    return res.redirect(urlEntry.originalUrl);
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

export default router;
